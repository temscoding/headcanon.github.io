const $ = (s) => document.querySelector(s);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const rich = (s) => esc(s).replace(/\|\|(.+?)\|\|/gs, '<span class="sp" tabindex="0" data-a="reveal">$1</span>').replace(/\n/g, '<br>');
const STAT = { want: 'Want to read', reading: 'Reading', finished: 'Finished', rereading: 'Re-reading', dnf: 'Not for me' };
const REACT = ['needs to be read', 'made me cry', 'added to my TBR'];
const THEMES = { coffee: 'Coffee Shop', midnight: 'Midnight Library', rose: 'Rose Garden', moor: 'Foggy Moor' };
let me = null, view = { feedScope: 'all', feedQ: '', dq: '', dkind: '', shelfF: 'all' };

async function api(p, m = 'GET', b) {
  const r = await fetch('/api' + p, { method: m, headers: b ? { 'Content-Type': 'application/json' } : {}, body: b ? JSON.stringify(b) : undefined });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || 'Something went wrong.');
  return d;
}
const toast = (m) => { const t = $('#toast'); t.textContent = m; t.hidden = false; clearTimeout(toast.t); toast.t = setTimeout(() => (t.hidden = true), 2600); };
const stars = (n) => (n ? '<span class="stars" aria-label="' + n + ' out of 5">' + '★'.repeat(n) + '☆'.repeat(5 - n) + '</span>' : '');
const tags = (a) => (a || []).map((t) => `<span class="tag">${esc(t)}</span>`).join('');
const empty = (t) => `<p class="empty">${t}</p>`;
const ago = (t) => new Date(t).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });
const opts = (o, sel) => Object.entries(o).map(([k, v]) => `<option value="${k}"${k === sel ? ' selected' : ''}>${v}</option>`).join('');
const workH = (w) => `<div class="work"><b>${w.url ? `<a href="${esc(w.url)}" target="_blank" rel="noopener noreferrer">${esc(w.title)}</a>` : esc(w.title)}</b>
  <span class="m">by ${esc(w.author)} · ${w.kind === 'fic' ? 'Fanfic' : 'Book'}${w.fandom ? ' · ' + esc(w.fandom) : ''}${w.words ? ' · ' + Number(w.words).toLocaleString() + ' words' : ''}</span><div>${tags(w.tags)}</div></div>`;
const postH = (p) => `<article class="card post"><div class="m"><a href="#u/${esc(p.user)}">@${esc(p.user)}</a> · ${ago(p.created)} ${stars(p.rating)}</div>
  <h3>${esc(p.title)}</h3>${p.work ? workH(p.work) : ''}<div class="body">${rich(p.body)}</div><div>${tags(p.tags)}</div>
  <div class="row">${REACT.map((k) => `<button class="chip${p.mine.includes(k) ? ' on' : ''}" data-a="react" data-id="${p.id}" data-k="${k}">${k}${p.counts[k] ? ' (' + p.counts[k] + ')' : ''}</button>`).join('')}
  ${p.own ? `<button class="chip" data-a="delpost" data-id="${p.id}">Delete</button>` : ''}</div></article>`;

const V = {
  async auth(mode = 'login') {
    $('#app').innerHTML = `<form class="card auth" data-f="${mode}"><h2>${mode === 'login' ? 'Welcome back' : 'Join Headcanon'}</h2>
      <p class="m">${mode === 'login' ? 'Log in to see your shelves.' : 'Pick a pseudonym. You never need your real name.'}</p>
      <label for="u">Username</label><input id="u" name="username" autocomplete="username" required>
      <label for="p">Password</label><input id="p" name="password" type="password" autocomplete="${mode === 'login' ? 'current-password' : 'new-password'}" minlength="${mode === 'login' ? 1 : 10}" required>
      ${mode === 'register' ? '<p class="hint">At least 10 characters. Headcanon is for readers aged 18 and over.</p>' : ''}
      <div class="row"><button>${mode === 'login' ? 'Log in' : 'Create account'}</button><button type="button" class="ghost" data-a="authmode" data-m="${mode === 'login' ? 'register' : 'login'}">${mode === 'login' ? 'Create an account' : 'I have an account'}</button></div></form>`;
  },
  async feed() {
    const d = await api(`/feed?scope=${view.feedScope}&q=${encodeURIComponent(view.feedQ)}`);
    $('#app').innerHTML = `<h2>Feed</h2><div class="row"><button class="chip${view.feedScope === 'all' ? ' on' : ''}" data-a="scope" data-s="all">Everyone</button>
      <button class="chip${view.feedScope === 'following' ? ' on' : ''}" data-a="scope" data-s="following">Following</button>
      <form data-f="feedq" class="grow"><input name="q" value="${esc(view.feedQ)}" placeholder="Search posts" aria-label="Search posts"></form></div>
      ${d.hidden ? `<p class="hint">${d.hidden} post${d.hidden > 1 ? 's' : ''} hidden by your blacklist.</p>` : ''}
      ${d.posts.length ? d.posts.map(postH).join('') : empty(view.feedScope === 'following' ? 'Follow some readers to fill this feed.' : 'Nothing here yet. <a href="#write">Write the first post.</a>')}`;
  },
  async discover() {
    const d = await api(`/works?q=${encodeURIComponent(view.dq)}&kind=${view.dkind}`);
    $('#app').innerHTML = `<h2>Discover</h2><form data-f="dq" class="row"><input class="grow" name="q" value="${esc(view.dq)}" placeholder="Search titles, authors, fandoms or tags" aria-label="Search works">
      <select name="kind" style="width:auto" aria-label="Type">${opts({ '': 'Books and fanfic', fic: 'Fanfic', book: 'Books' }, view.dkind)}</select><button>Search</button></form>
      ${d.hidden ? `<p class="hint">${d.hidden} work${d.hidden > 1 ? 's' : ''} hidden by your blacklist.</p>` : ''}
      ${d.works.length ? d.works.map((w) => `<div class="card">${workH(w)}<div class="row"><span class="m">${w.shelved} shelved</span>
      <select style="width:auto" data-c="addshelf" data-id="${w.id}" aria-label="Add to shelf"><option value="">Add to shelf…</option>${opts(STAT)}</select></div></div>`).join('') : empty('No works yet. <a href="#add">Add the first one.</a>')}`;
  },
  async shelf() {
    const all = await api('/shelf'), f = view.shelfF, list = f === 'all' ? all : all.filter((w) => w.status === f);
    $('#app').innerHTML = `<h2>My shelf</h2><div class="row">${['all', ...Object.keys(STAT)].map((k) => `<button class="chip${f === k ? ' on' : ''}" data-a="shelff" data-s="${k}">${k === 'all' ? 'All' : STAT[k]} (${k === 'all' ? all.length : all.filter((w) => w.status === k).length})</button>`).join('')}</div>
      ${list.length ? list.map((w) => `<div class="card" data-w="${w.id}">${workH(w)}<div class="row">
        <select style="width:auto" data-c="shelfup" aria-label="Status" name="status">${opts(STAT, w.status)}</select>
        <select style="width:auto" data-c="shelfup" aria-label="Rating" name="rating"><option value="">Unrated</option>${[1, 2, 3, 4, 5].map((n) => `<option value="${n}"${w.rating === n ? ' selected' : ''}>${'★'.repeat(n)}</option>`).join('')}</select>
        <label style="margin:0;font-weight:600"><input type="checkbox" data-c="shelfup" name="private"${w.private ? ' checked' : ''}> Private</label>
        <button class="chip" data-a="unshelf" data-id="${w.id}">Remove</button></div>
        <input data-c="shelfup" name="note" value="${esc(w.note)}" placeholder="A private note (who recced it, how it wrecked you)" maxlength="1000" aria-label="Note"></div>`).join('')
        : empty('Nothing here yet. Your headcanon starts with one fic. <a href="#add">Add a work.</a>')}`;
    $('#app')._shelf = all;
  },
  async add() {
    $('#app').innerHTML = `<h2>Add a work</h2><p class="hint">Paste the link and type the details. Headcanon does not copy or fetch anything from other sites; it only links back to the original.</p>
      <form class="card" data-f="addwork"><label>Link (optional)</label><input name="url" type="url" placeholder="https://archiveofourown.org/works/…">
      <label>Title</label><input name="title" required maxlength="200"><label>Author</label><input name="author" required maxlength="100">
      <div class="row"><div class="grow"><label>Type</label><select name="kind"><option value="fic">Fanfic</option><option value="book">Published book</option></select></div>
      <div class="grow"><label>Fandom</label><input name="fandom" maxlength="100"></div><div class="grow"><label>Word count</label><input name="words" type="number" min="0"></div></div>
      <label>Tags (comma separated)</label><input name="tags" placeholder="slow burn, hurt/comfort">
      <label>Add to my shelf as</label><select name="status">${opts(STAT, 'want')}</select><div class="row"><button>Save work</button></div></form>`;
  },
  async write() {
    const sh = await api('/shelf');
    $('#app').innerHTML = `<h2>Write a post</h2><form class="card" data-f="post"><label>About a work (optional)</label>
      <select name="workId"><option value="">No work attached</option>${sh.map((w) => `<option value="${w.id}">${esc(w.title)} by ${esc(w.author)}</option>`).join('')}</select>
      <label>Title</label><input name="title" required maxlength="150"><label>Your post</label><textarea name="body" required maxlength="20000"></textarea>
      <p class="hint">Hide spoilers by wrapping text in two bars, like ||this||. Readers tap to reveal.</p>
      <div class="row"><div class="grow"><label>Rating</label><select name="rating"><option value="">No rating</option>${[1, 2, 3, 4, 5].map((n) => `<option value="${n}">${'★'.repeat(n)}</option>`).join('')}</select></div>
      <div class="grow"><label>Tags (comma separated)</label><input name="tags"></div></div><div class="row"><button>Publish</button></div></form>`;
  },
  async me() {
    $('#app').innerHTML = `<h2>Settings</h2><form class="card" data-f="settings"><label>Bio</label><textarea name="bio" maxlength="500" style="min-height:80px">${esc(me.bio)}</textarea>
      <label>Theme</label><select name="theme">${opts(THEMES, me.theme)}</select>
      <label>Blacklist (comma separated tags to hide everywhere)</label><input name="blacklist" value="${esc(me.blacklist.join(', '))}">
      <div class="row"><button>Save changes</button><a class="btn ghost" href="#u/${esc(me.username)}">View my profile</a></div></form>
      <div class="card"><h3>Your data</h3><p class="m">Download everything you have saved, or delete your account and all of it.</p>
      <div class="row"><a class="btn ghost" href="/api/export">Download my data</a><button class="ghost" data-a="logout">Log out</button><button class="danger" data-a="delacct">Delete my account</button></div></div>`;
  },
  async profile(name) {
    const u = await api('/u/' + encodeURIComponent(name));
    document.body.dataset.theme = u.theme;
    $('#app').innerHTML = `<div class="card"><h2>@${esc(u.username)}</h2><p>${esc(u.bio) || '<span class="m">No bio yet.</span>'}</p><p class="m">${u.followers} follower${u.followers === 1 ? '' : 's'}</p>
      ${u.self ? '<a class="btn ghost" href="#me">Edit profile</a>' : `<button data-a="follow" data-n="${esc(u.username)}">${u.following ? 'Following' : 'Follow'}</button>`}</div>
      <h3>Shelf</h3>${u.shelf.length ? u.shelf.map((w) => `<div class="card">${workH(w)}<span class="m">${STAT[w.status]}</span> ${stars(w.rating)}</div>`).join('') : empty('No public shelf yet.')}
      <h3>Posts</h3>${u.posts.length ? u.posts.map(postH).join('') : empty('No posts yet.')}`;
  },
};

function nav(h) {
  $('#nav').innerHTML = me ? [['feed', 'Feed'], ['discover', 'Discover'], ['shelf', 'Shelf'], ['add', 'Add'], ['write', 'Write'], ['me', '@' + me.username]]
    .map(([k, v]) => `<a href="#${k}" class="${h === k ? 'on' : ''}">${esc(v)}</a>`).join('') : '';
}
async function route() {
  const h = location.hash.slice(1) || 'feed';
  try {
    me = await api('/me');
    document.body.dataset.theme = me ? me.theme : 'coffee';
    nav(h.split('/')[0]);
    if (!me) return V.auth();
    if (h.startsWith('u/')) return await V.profile(decodeURIComponent(h.slice(2)));
    await (V[h] || V.feed)();
  } catch (e) { toast(e.message); }
  window.scrollTo(0, 0);
}
const act = {
  async login(d) { await api('/login', 'POST', d); route(); },
  async register(d) { await api('/register', 'POST', d); route(); },
  async feedq(d) { view.feedQ = d.q; V.feed(); },
  async dq(d) { view.dq = d.q; view.dkind = d.kind; V.discover(); },
  async addwork(d) {
    const { id } = await api('/works', 'POST', d);
    await api('/shelf/' + id, 'PUT', { status: d.status });
    toast('Saved to your shelf.'); location.hash = 'shelf';
  },
  async post(d) { await api('/posts', 'POST', d); toast('Published.'); location.hash = 'feed'; },
  async settings(d) { await api('/me', 'PATCH', d); toast('Saved.'); route(); },
};
document.addEventListener('submit', async (e) => {
  const f = e.target.dataset.f; if (!f) return;
  e.preventDefault();
  try { await act[f](Object.fromEntries(new FormData(e.target))); } catch (x) { toast(x.message); }
});
document.addEventListener('click', async (e) => {
  const b = e.target.closest('[data-a]'); if (!b) return;
  const a = b.dataset.a, D = b.dataset;
  try {
    if (a === 'reveal') return b.classList.toggle('show');
    if (a === 'authmode') return V.auth(D.m);
    if (a === 'scope') { view.feedScope = D.s; return V.feed(); }
    if (a === 'shelff') { view.shelfF = D.s; return V.shelf(); }
    if (a === 'react') { await api(`/posts/${D.id}/react`, 'POST', { kind: D.k }); return route(); }
    if (a === 'delpost') { if (confirm('Delete this post?')) { await api('/posts/' + D.id, 'DELETE'); route(); } return; }
    if (a === 'unshelf') { await api('/shelf/' + D.id, 'DELETE'); return V.shelf(); }
    if (a === 'follow') { const r = await api('/follow/' + D.n, 'POST'); b.textContent = r.following ? 'Following' : 'Follow'; return; }
    if (a === 'logout') { await api('/logout', 'POST'); location.hash = 'feed'; return route(); }
    if (a === 'delacct' && confirm('Delete your account, shelves and posts? This cannot be undone.')) { await api('/me', 'DELETE'); location.hash = 'feed'; route(); }
  } catch (x) { toast(x.message); }
});
document.addEventListener('change', async (e) => {
  const c = e.target.dataset.c; if (!c) return;
  try {
    if (c === 'addshelf' && e.target.value) { await api('/shelf/' + e.target.dataset.id, 'PUT', { status: e.target.value }); toast('Added to your shelf.'); e.target.value = ''; }
    if (c === 'shelfup') {
      const card = e.target.closest('[data-w]'), g = (n) => card.querySelector(`[name=${n}]`);
      await api('/shelf/' + card.dataset.w, 'PUT', { status: g('status').value, rating: g('rating').value, private: g('private').checked, note: g('note').value });
      toast('Saved.');
    }
  } catch (x) { toast(x.message); }
});
window.addEventListener('hashchange', route);
route();
