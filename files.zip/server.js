import express from 'express';
import Database from 'better-sqlite3';
import crypto from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const dir = path.dirname(fileURLToPath(import.meta.url));
const prod = process.env.NODE_ENV === 'production';
const db = new Database(process.env.DB_PATH || path.join(dir, 'headcanon.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE COLLATE NOCASE, hash TEXT, bio TEXT DEFAULT '', theme TEXT DEFAULT 'coffee', blacklist TEXT DEFAULT '[]', created INTEGER);
CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY, user_id INTEGER REFERENCES users(id) ON DELETE CASCADE, created INTEGER);
CREATE TABLE IF NOT EXISTS works(id INTEGER PRIMARY KEY, url TEXT UNIQUE, title TEXT, author TEXT, kind TEXT, fandom TEXT DEFAULT '', words INTEGER, tags TEXT DEFAULT '[]', added_by INTEGER, created INTEGER);
CREATE TABLE IF NOT EXISTS shelf(user_id INTEGER REFERENCES users(id) ON DELETE CASCADE, work_id INTEGER REFERENCES works(id) ON DELETE CASCADE, status TEXT, rating INTEGER, note TEXT DEFAULT '', private INTEGER DEFAULT 0, updated INTEGER, PRIMARY KEY(user_id, work_id));
CREATE TABLE IF NOT EXISTS posts(id INTEGER PRIMARY KEY, user_id INTEGER REFERENCES users(id) ON DELETE CASCADE, work_id INTEGER REFERENCES works(id) ON DELETE SET NULL, title TEXT, body TEXT, rating INTEGER, tags TEXT DEFAULT '[]', created INTEGER);
CREATE TABLE IF NOT EXISTS reactions(post_id INTEGER REFERENCES posts(id) ON DELETE CASCADE, user_id INTEGER REFERENCES users(id) ON DELETE CASCADE, kind TEXT, PRIMARY KEY(post_id, user_id, kind));
CREATE TABLE IF NOT EXISTS follows(follower INTEGER REFERENCES users(id) ON DELETE CASCADE, followee INTEGER REFERENCES users(id) ON DELETE CASCADE, PRIMARY KEY(follower, followee));
`);

const STATUS = ['want', 'reading', 'finished', 'rereading', 'dnf'];
const REACT = ['needs to be read', 'made me cry', 'added to my TBR'];
const THEMES = ['coffee', 'midnight', 'rose', 'moor'];
const now = () => Date.now();
const J = (s) => { try { return JSON.parse(s) || []; } catch { return []; } };
const clip = (s, n) => String(s ?? '').trim().slice(0, n);
const tagList = (a) => [...new Set((Array.isArray(a) ? a : String(a || '').split(',')).map((t) => String(t).trim().toLowerCase().slice(0, 40)).filter(Boolean))].slice(0, 30);
const rating = (n) => { n = Number(n); return n >= 1 && n <= 5 ? Math.round(n) : null; };
const bad = (r, m, c = 400) => r.status(c).json({ error: m });
const hashPw = (p) => { const s = crypto.randomBytes(16); return s.toString('hex') + ':' + crypto.scryptSync(p, s, 64).toString('hex'); };
const checkPw = (p, h) => { const [s, k] = h.split(':'); return crypto.timingSafeEqual(crypto.scryptSync(p, Buffer.from(s, 'hex'), 64), Buffer.from(k, 'hex')); };
const safe = (u) => ({ id: u.id, username: u.username, bio: u.bio, theme: u.theme, blacklist: J(u.blacklist) });
const blocked = (q, tags) => { const b = J(q.user.blacklist); return b.some((t) => tags.includes(t)); };
const workOut = (w) => ({ ...w, tags: J(w.tags) });

const app = express();
app.disable('x-powered-by');
if (prod) app.set('trust proxy', 1);
app.use(express.json({ limit: '100kb' }));
app.use((q, r, n) => {
  r.set({
    'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'same-origin',
    'Content-Security-Policy': "default-src 'self'; style-src 'self' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data:; frame-ancestors 'none'",
  });
  n();
});

const hits = new Map();
const limit = (q, r, n) => {
  const t = now(), a = (hits.get(q.ip) || []).filter((x) => t - x < 9e5);
  if (a.length >= 20) return bad(r, 'Too many attempts. Try again in a few minutes.', 429);
  a.push(t); hits.set(q.ip, a); n();
};
const cookies = (q) => Object.fromEntries((q.headers.cookie || '').split(';').map((c) => c.trim().split('=')).filter((c) => c[0]).map(([k, ...v]) => [k, v.join('=')]));
app.use((q, r, n) => {
  const t = cookies(q).sid;
  q.user = t ? db.prepare('SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=? AND s.created>?').get(t, now() - 30 * 864e5) : null;
  n();
});
const need = (q, r, n) => (q.user ? n() : bad(r, 'Please log in.', 401));
const startSession = (r, id) => {
  const t = crypto.randomBytes(32).toString('hex');
  db.prepare('INSERT INTO sessions VALUES(?,?,?)').run(t, id, now());
  r.cookie('sid', t, { httpOnly: true, sameSite: 'lax', secure: prod, maxAge: 30 * 864e5 });
};

// ---- accounts
app.post('/api/register', limit, (q, r) => {
  const u = clip(q.body.username, 24), p = String(q.body.password || '');
  if (!/^[A-Za-z0-9_]{3,24}$/.test(u)) return bad(r, 'Usernames use 3 to 24 letters, numbers or underscores.');
  if (p.length < 10) return bad(r, 'Passwords need at least 10 characters.');
  try {
    const id = db.prepare('INSERT INTO users(username,hash,created) VALUES(?,?,?)').run(u, hashPw(p), now()).lastInsertRowid;
    startSession(r, id); r.json({ ok: 1 });
  } catch { bad(r, 'That username is taken.', 409); }
});
app.post('/api/login', limit, (q, r) => {
  const u = db.prepare('SELECT * FROM users WHERE username=?').get(clip(q.body.username, 24));
  if (!u || !checkPw(String(q.body.password || ''), u.hash)) return bad(r, 'Wrong username or password.', 401);
  startSession(r, u.id); r.json({ ok: 1 });
});
app.post('/api/logout', (q, r) => {
  const t = cookies(q).sid; if (t) db.prepare('DELETE FROM sessions WHERE token=?').run(t);
  r.clearCookie('sid'); r.json({ ok: 1 });
});
app.get('/api/me', (q, r) => r.json(q.user ? safe(q.user) : null));
app.patch('/api/me', need, (q, r) => {
  const b = q.body, theme = THEMES.includes(b.theme) ? b.theme : q.user.theme;
  db.prepare('UPDATE users SET bio=?, theme=?, blacklist=? WHERE id=?').run(clip(b.bio, 500), theme, JSON.stringify(tagList(b.blacklist)), q.user.id);
  r.json(safe(db.prepare('SELECT * FROM users WHERE id=?').get(q.user.id)));
});
app.delete('/api/me', need, (q, r) => { db.prepare('DELETE FROM users WHERE id=?').run(q.user.id); r.clearCookie('sid'); r.json({ ok: 1 }); });
app.get('/api/export', need, (q, r) => {
  const id = q.user.id;
  r.attachment('headcanon-export.json').json({
    user: safe(q.user),
    shelf: db.prepare('SELECT w.*, s.status, s.rating, s.note, s.private FROM shelf s JOIN works w ON w.id=s.work_id WHERE s.user_id=?').all(id).map(workOut),
    posts: db.prepare('SELECT * FROM posts WHERE user_id=?').all(id).map((p) => ({ ...p, tags: J(p.tags) })),
  });
});

// ---- works (metadata entered by the user; nothing is fetched from other sites)
app.post('/api/works', need, (q, r) => {
  const b = q.body, title = clip(b.title, 200), author = clip(b.author, 100);
  let url = null;
  if (b.url) {
    try { const u = new URL(String(b.url).trim()); if (!/^https?:$/.test(u.protocol)) throw 0; u.hash = ''; url = u.toString().replace(/\/$/, ''); }
    catch { return bad(r, 'That link does not look right. Use a full https:// address.'); }
  }
  if (!title || !author) return bad(r, 'Add a title and an author.');
  if (url) { const e = db.prepare('SELECT id FROM works WHERE url=?').get(url); if (e) return r.json({ id: e.id }); }
  const kind = b.kind === 'book' ? 'book' : 'fic';
  const id = db.prepare('INSERT INTO works(url,title,author,kind,fandom,words,tags,added_by,created) VALUES(?,?,?,?,?,?,?,?,?)')
    .run(url, title, author, kind, clip(b.fandom, 100), Math.max(0, parseInt(b.words) || 0) || null, JSON.stringify(tagList(b.tags)), q.user.id, now()).lastInsertRowid;
  r.json({ id });
});
app.get('/api/works', need, (q, r) => {
  const s = '%' + clip(q.query.q, 80) + '%', k = q.query.kind === 'fic' || q.query.kind === 'book' ? q.query.kind : '';
  const rows = db.prepare(`SELECT w.*, (SELECT COUNT(*) FROM shelf WHERE work_id=w.id AND private=0) shelved FROM works w
    WHERE (w.title LIKE ?1 OR w.author LIKE ?1 OR w.fandom LIKE ?1 OR w.tags LIKE ?1) AND (?2='' OR w.kind=?2) ORDER BY shelved DESC, w.id DESC LIMIT 100`).all(s, k);
  const out = rows.map(workOut), hidden = out.filter((w) => blocked(q, w.tags)).length;
  r.json({ works: out.filter((w) => !blocked(q, w.tags)), hidden });
});

// ---- shelf
app.get('/api/shelf', need, (q, r) => r.json(db.prepare('SELECT w.*, s.status, s.rating, s.note, s.private FROM shelf s JOIN works w ON w.id=s.work_id WHERE s.user_id=? ORDER BY s.updated DESC').all(q.user.id).map(workOut)));
app.put('/api/shelf/:id', need, (q, r) => {
  const b = q.body, id = parseInt(q.params.id);
  if (!STATUS.includes(b.status)) return bad(r, 'Pick a reading status.');
  if (!db.prepare('SELECT 1 FROM works WHERE id=?').get(id)) return bad(r, 'We could not find that work.', 404);
  db.prepare(`INSERT INTO shelf(user_id,work_id,status,rating,note,private,updated) VALUES(?,?,?,?,?,?,?)
    ON CONFLICT(user_id,work_id) DO UPDATE SET status=excluded.status, rating=excluded.rating, note=excluded.note, private=excluded.private, updated=excluded.updated`)
    .run(q.user.id, id, b.status, rating(b.rating), clip(b.note, 1000), b.private ? 1 : 0, now());
  r.json({ ok: 1 });
});
app.delete('/api/shelf/:id', need, (q, r) => { db.prepare('DELETE FROM shelf WHERE user_id=? AND work_id=?').run(q.user.id, parseInt(q.params.id)); r.json({ ok: 1 }); });

// ---- posts and feed
const postRows = (q, where, args) => db.prepare(`SELECT p.*, u.username, w.title wt, w.author wa, w.url wu, w.kind wk, w.fandom wf, w.tags wtags,
  (SELECT group_concat(kind||'|'||user_id, ';') FROM reactions WHERE post_id=p.id) rx
  FROM posts p JOIN users u ON u.id=p.user_id LEFT JOIN works w ON w.id=p.work_id WHERE ${where} ORDER BY p.id DESC LIMIT 100`).all(...args)
  .map((p) => {
    const rx = (p.rx || '').split(';').filter(Boolean).map((x) => x.split('|')), counts = {}, mine = [];
    rx.forEach(([k, u]) => { counts[k] = (counts[k] || 0) + 1; if (+u === q.user.id) mine.push(k); });
    const tags = [...J(p.tags), ...J(p.wtags)];
    return { id: p.id, user: p.username, title: p.title, body: p.body, rating: p.rating, created: p.created, tags: J(p.tags), counts, mine, own: p.user_id === q.user.id, _t: tags,
      work: p.work_id ? { id: p.work_id, title: p.wt, author: p.wa, url: p.wu, kind: p.wk, fandom: p.wf } : null };
  });
app.post('/api/posts', need, (q, r) => {
  const b = q.body, title = clip(b.title, 150), body = clip(b.body, 20000);
  if (!title || !body) return bad(r, 'Add a title and some text.');
  const wid = parseInt(b.workId) || null;
  if (wid && !db.prepare('SELECT 1 FROM works WHERE id=?').get(wid)) return bad(r, 'We could not find that work.', 404);
  const id = db.prepare('INSERT INTO posts(user_id,work_id,title,body,rating,tags,created) VALUES(?,?,?,?,?,?,?)').run(q.user.id, wid, title, body, rating(b.rating), JSON.stringify(tagList(b.tags)), now()).lastInsertRowid;
  r.json({ id });
});
app.get('/api/feed', need, (q, r) => {
  const s = '%' + clip(q.query.q, 80) + '%', f = q.query.scope === 'following' ? 1 : 0, me = q.user.id;
  const rows = postRows(q, `(?=0 OR p.user_id=? OR p.user_id IN (SELECT followee FROM follows WHERE follower=?)) AND (p.title LIKE ? OR p.body LIKE ?)`, [f, me, me, s, s]);
  const posts = rows.filter((p) => p.own || !blocked(q, p._t)).map(({ _t, ...p }) => p);
  r.json({ posts, hidden: rows.length - posts.length });
});
app.delete('/api/posts/:id', need, (q, r) => { db.prepare('DELETE FROM posts WHERE id=? AND user_id=?').run(parseInt(q.params.id), q.user.id); r.json({ ok: 1 }); });
app.post('/api/posts/:id/react', need, (q, r) => {
  const k = q.body.kind, id = parseInt(q.params.id);
  if (!REACT.includes(k) || !db.prepare('SELECT 1 FROM posts WHERE id=?').get(id)) return bad(r, 'That reaction is not available.');
  const del = db.prepare('DELETE FROM reactions WHERE post_id=? AND user_id=? AND kind=?').run(id, q.user.id, k);
  if (!del.changes) db.prepare('INSERT INTO reactions VALUES(?,?,?)').run(id, q.user.id, k);
  r.json({ ok: 1 });
});

// ---- people
app.post('/api/follow/:name', need, (q, r) => {
  const u = db.prepare('SELECT id FROM users WHERE username=?').get(q.params.name);
  if (!u || u.id === q.user.id) return bad(r, 'You cannot follow that account.');
  const del = db.prepare('DELETE FROM follows WHERE follower=? AND followee=?').run(q.user.id, u.id);
  if (!del.changes) db.prepare('INSERT INTO follows VALUES(?,?)').run(q.user.id, u.id);
  r.json({ following: !del.changes });
});
app.get('/api/u/:name', need, (q, r) => {
  const u = db.prepare('SELECT * FROM users WHERE username=?').get(q.params.name);
  if (!u) return bad(r, 'We could not find that reader.', 404);
  const posts = postRows(q, 'p.user_id=?', [u.id]).map(({ _t, ...p }) => p);
  const shelf = db.prepare('SELECT w.*, s.status, s.rating FROM shelf s JOIN works w ON w.id=s.work_id WHERE s.user_id=? AND s.private=0 ORDER BY s.updated DESC').all(u.id).map(workOut);
  r.json({ username: u.username, bio: u.bio, theme: u.theme, self: u.id === q.user.id, posts, shelf,
    following: !!db.prepare('SELECT 1 FROM follows WHERE follower=? AND followee=?').get(q.user.id, u.id),
    followers: db.prepare('SELECT COUNT(*) c FROM follows WHERE followee=?').get(u.id).c });
});

app.use(express.static(path.join(dir, 'public')));
app.use('/api', (q, r) => bad(r, 'Not found.', 404));
app.use((e, q, r, n) => { console.error(e); bad(r, 'Something went wrong on our side.', 500); });
app.listen(process.env.PORT || 3000, () => console.log('Headcanon is running on port ' + (process.env.PORT || 3000)));
