# Headcanon

A cosy hub for book and fanfic readers: track what you read, review it, follow other readers, and keep a personal blacklist. Works are **linked, never copied**. You type in the details and Headcanon links back to the original site.

**Stack:** Node.js, Express, SQLite (better-sqlite3), plain HTML/CSS/JS. No build step.

## Run it

```bash
npm install
npm start          # http://localhost:3000
```

Copy `.env.example` to `.env` if you want to change the port or database path (set them in your shell or host, since the app reads `process.env` directly).

## What works

- Accounts (scrypt-hashed passwords, httpOnly session cookie, login rate limiting)
- Add works by link plus typed details; shelf statuses, ratings, private notes, per-work privacy
- Reviews and posts with `||spoiler||` text, reactions, tags
- Feed (everyone or following), Discover search, follows, public profiles with 4 themes
- Blacklist applied server-side to Discover and the feed
- Data export (JSON) and full account deletion

## Deploy

- **Docker:** `docker build -t headcanon .` then run with a volume on `/data` so the database survives restarts.
- **Render, Railway, Fly.io:** any Node host works. Mount a persistent disk and set `DB_PATH` to a file on it, and set `NODE_ENV=production` (enables secure cookies; serve over HTTPS).
- SQLite suits a single instance. If you need several instances, move to Postgres.

## Not built yet (needed before a public launch)

- Email verification and password reset (accounts have no email at the moment)
- Moderation: reporting, blocking and muting, admin tools
- Age assurance and a proper Terms, Privacy Policy and takedown process. If you serve UK users, check Ofcom's Online Safety Act guidance and UK GDPR, and get legal advice
- Browser extension, imports from AO3/Goodreads exports, notifications, messaging
- Automated tests, CSRF tokens (cookies are SameSite=Lax and the API only accepts JSON), backups of the database file

## Notes on other sites

AO3 and other platforms restrict scraping and apps that host their content. This project deliberately doesn't fetch or store text from them. Check each site's current terms before adding any importer.
